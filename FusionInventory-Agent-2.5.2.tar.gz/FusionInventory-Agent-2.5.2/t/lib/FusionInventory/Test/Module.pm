package FusionInventory::Test::Module;

use strict;
use warnings;

sub mirror {
    return $_[0];
}

sub loop {
    while (1) {};
}

1;
